const express = require('express');
const path = require('path');
const fs = require('fs');
const axios = require('axios');

const app = express();

// إعداد بورت ديناميكي: يقرأ منفذ السيرفر العالمي تلقائياً أو يعود لـ 3000 محلياً
const PORT = process.env.PORT || 3000;

// توكن ومعرف شات التلغرام الخاص بك (مثبتة بدقة لضمان وصول الفواتير)
const TELEGRAM_TOKEN = '7259468697:AAFi88pUv1qQG35Y2Oq1HbeGv_Y1Z_Dlhco';
const TELEGRAM_CHAT_ID = '5023933100';

// تفعيل مفسرات البيانات القادمة من الواجهات
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// تشغيل المجلد الإستاتيكي العام بمسارات آمنة ومتوافقة سحابياً
app.use(express.static(path.join(__dirname, 'public')));

// تحديد مسار ديناميكي لملف المنتجات لضمان عدم ضياعه عند الرفع
const productsFilePath = path.join(__dirname, 'products.json');

// دالة مساعدة لقراءة المنتجات بأمان
const readProductsFile = () => {
    try {
        if (!fs.existsSync(productsFilePath)) {
            fs.writeFileSync(productsFilePath, JSON.stringify([]), 'utf8');
            return [];
        }
        const data = fs.readFileSync(productsFilePath, 'utf8');
        return JSON.parse(data || '[]');
    } catch (error) {
        console.error("❌ خطأ في قراءة قاعدة البيانات المحلية:", error);
        return [];
    }
};

// دالة مساعدة لحفظ المنتجات بأمان
const writeProductsFile = (data) => {
    try {
        fs.writeFileSync(productsFilePath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error("❌ خطأ في الكتابة والتخزين:", error);
        return false;
    }
};

// =================== [ المسارات البرمجية API ] ===================

// 1. جلب قائمة القطع والمنتجات المعروضة
app.get('/api/products', (req, res) => {
    const products = readProductsFile();
    res.json(products);
});

// 2. إدراج قطعة جديدة من لوحة التحكم الفاخرة
app.post('/api/products', (req, res) => {
    const { name, price, image } = req.body;
    const products = readProductsFile();
    
    const newProduct = {
        id: Date.now(), // توليد معرف فريد يعتمد على الوقت
        name: name,
        price: parseFloat(price) || 0,
        image: image || ''
    };
    
    products.push(newProduct);
    if (writeProductsFile(products)) {
        res.json({ success: true, product: newProduct });
    } else {
        res.status(500).json({ success: false, error: "فشل حفظ المنتج" });
    }
});

// 3. سحب وإلغاء عرض قطعة من المتجر
app.delete('/api/products/:id', (req, res) => {
    const id = parseInt(req.params.id);
    let products = readProductsFile();
    
    products = products.filter(p => p.id !== id);
    if (writeProductsFile(products)) {
        res.json({ success: true });
    } else {
        res.status(500).json({ success: false, error: "فشل حذف المنتج" });
    }
});

// 4. استقبال طلبات الزبائن وإرسال الفواتير الفورية للتلغرام
app.post('/api/orders', async (req, res) => {
    const { customer_name, customer_phone, customer_address, total_price, items } = req.body;

    // صياغة رسالة ملوكية تليق بهوية متجر Aura Store
    let textMessage = `✨ *طلب جديد ومميز في Aura Store!* ✨\n\n`;
    textMessage += `👤 *الزبون:* ${customer_name}\n`;
    textMessage += `📞 *الهاتف:* ${customer_phone}\n`;
    textMessage += `📍 *العنوان:* ${customer_address}\n\n`;
    textMessage += `🛍️ *المقتنيات المطلوبة:*\n`;
    
    items.forEach((itemName, index) => {
        textMessage += `  ${index + 1}. ${itemName}\n`;
    });
    
    textMessage += `\n💰 *الإجمالي النهائي:* $${total_price.toFixed(2)}`;

    try {
        // بث الإشعار الفوري مباشرة لبوت التلغرام
        await axios.post(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
            chat_id: TELEGRAM_CHAT_ID,
            text: textMessage,
            parse_mode: 'Markdown'
        });

        res.json({ success: true });
    } catch (error) {
        console.error("❌ فشل إرسال الفاتورة إلى بوت التلغرام:", error.message);
        res.status(500).json({ success: false, error: "فشل إرسال الإشعار السحابي" });
    }
});

// تشغيل السيرفر بالمنفذ المتغير المتوافق عالمياً ومحلياً
app.listen(PORT, () => {
    console.log(`🚀 السيرفر يعمل بنجاح على بورت: ${PORT}`);
});